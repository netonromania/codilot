import { createContext } from "react";  //authentication setup

export const UserDetailContext = createContext();