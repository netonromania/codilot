import { createContext } from "react";

export const MessagesContext = createContext();

//used for storing the user input values and can be accessed by any component import and user input can be redirected first wrapped inside provider.jsx