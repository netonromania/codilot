import { createContext } from "react";

export const ActionContext = createContext();